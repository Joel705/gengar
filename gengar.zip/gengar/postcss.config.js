module.exports = {
  plugins: {
    "postcss-nesting": true
  }
};
